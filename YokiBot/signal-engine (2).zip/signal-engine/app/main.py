from fastapi import FastAPI

from app.engine.decision_logger import generate_decision
from app.engine.evaluate_credit_spread import evaluate_credit_spread
from app.engine.models import DecideRequest, DecisionResult
from filters import run_filters
from app.dashboard.state import get_latest_decision

app = FastAPI(title="Signal Engine")

# =====================
# HEALTH
# =====================
@app.get("/health")
def health():
    return {"status": "SIGNAL ENGINE LIVE"}

# =====================
# CORE DECISION
# =====================
@app.post("/decide", response_model=DecisionResult)
def decide(req: DecideRequest):
    decision = evaluate_credit_spread(req)

    # 🔒 STORE DECISION FOR DASHBOARD
    from app.engine.decision_logger import save_decision
    save_decision(decision.model_dump())

    return decision


# =====================
# MANUAL SIGNAL
# =====================
@app.get("/signal")
def signal():
    decision = generate_decision()
    return decision.model_dump()

# =====================
# DASHBOARD
# =====================
@app.get("/latest_decision")
def latest_decision():
    return get_latest_decision()

@app.get("/strategy_state")
def strategy_state():
    data = get_latest_decision()
    decision = data.get("decision")

    if not decision:
        return {"state": "INIT", "last_updated": None}

    return {
        "strategy": decision["strategy"],
        "action": decision["action"],
        "reason": decision["reason"],
        "last_updated": data["last_updated"],
    }
