from pydantic import BaseModel

class FilterResult(BaseModel):
    allowed: bool
    reason: str | None = None
