import time
from .filter_result import FilterResult
from app.redis_client import redis_client

MAX_STALE_SECONDS = 3

def data_freshness_filter() -> FilterResult:
    ts = redis_client.get("live:last_packet_ts")

    if not ts:
        return FilterResult(allowed=False, reason="NO_WS_HEARTBEAT")

  if not ts:
    return FilterResult(False, "NO_LIVE_DATA")

try:
    ts = float(ts)
except (TypeError, ValueError):
    return FilterResult(False, "BAD_TIMESTAMP")

age = time.time() - ts


    if age > MAX_STALE_SECONDS:
        return FilterResult(
            allowed=False,
            reason=f"STALE_MARKET_DATA_{int(age)}s"
        )

    return FilterResult(allowed=True)
